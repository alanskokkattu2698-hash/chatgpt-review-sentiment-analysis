# ChatGPT App Reviews: Sentiment Analysis & Feature Extraction

An NLP project that analyses ~197,000 user reviews of the ChatGPT mobile app to understand **how users feel**, **how opinionated they are**, and **which features they praise or criticise**.

## Project Overview

Star ratings show how happy users are, but not *why*. This project turns free-text reviews into measurable signals so a product team can see what to protect and what to fix first.

**Questions answered**
1. What is the overall sentiment users express about ChatGPT? (polarity)
2. How strong or opinionated is that sentiment? (subjectivity)
3. Does text sentiment agree with star ratings?
4. Which words, phrases and product aspects do users most often praise or criticise?

## Dataset

`data/chatgpt_reviews.csv`: 196,727 reviews (Jul 2023 to Aug 2024).

| Column | Description |
|---|---|
| Review Id | Unique review identifier |
| Review | Review text |
| Ratings | Star rating (1 to 5) |
| Review Date | Timestamp of the review |

## Methodology

1. **Data preparation:** standardised column names, parsed dates, converted ratings to numeric, filled 6 empty reviews, removed 3,573 duplicate review IDs (kept the latest), created `clean_text` and `word_count`.
2. **EDA:** rating distribution, review length, monthly volume, length and average rating over time.
3. **Sentiment analysis (TextBlob):** polarity (-1 to +1) and subjectivity (0 to 1) per review. Categories: Positive (> 0.1), Neutral, Negative (< -0.1). Compared against star ratings.
4. **Text analysis:** unigram and bigram frequencies (`CountVectorizer`) for positively rated reviews (4 to 5 stars), a word cloud, and a log-ratio comparison of 1 to 2 star vs 4 to 5 star reviews to find terms specific to complaints.
5. **Aspect analysis:** keyword groups (login, bugs, pricing, speed, voice, etc.) with mention counts, average rating and share of low-rated reviews.

## Key Findings

- **Sentiment:** 76.7% positive, 20.1% neutral, 3.3% negative. Mean polarity 0.46, mean subjectivity 0.53, mean rating 4.50.
- **Text vs stars:** polarity rises with rating (0.01 at 1 star to 0.52 at 5 stars), but the correlation is only about 0.27 and 31% of 1 to 2 star reviews read as positive. Text sentiment alone under-detects complaints.
- **Praise:** "good", "best", "helpful", "love"; phrases like "helps a lot", "user friendly", "better than Google". Helpfulness/learning is the most-mentioned aspect (14.6% of reviews) and the best rated (4.70).
- **Criticism is operational, not about AI capability:** login/verification averages 1.95 stars (1.2% of reviews but 11.4% of all low-rated reviews); bugs/errors average 2.40 stars (13.8% of low-rated reviews). Pricing and usage limits follow.
- **Trend:** mean polarity rose from about 0.38 to about 0.50 and the negative share fell from about 4.5% to 2.6%.

### Recommendations
1. Make sign-up, login and verification more reliable.
2. Improve stability and error messaging.
3. Be clearer about free vs paid features and usage limits.
4. Protect strengths: ease of use and learning help.
5. Track aspect mentions, not just the average rating.

## Visuals

| | |
|---|---|
| ![Sentiment distribution](images/sentiment_distribution.png) | ![Sentiment vs rating](images/sentiment_vs_rating.png) |
| ![Positive keywords](images/positive_keywords.png) | ![Aspect analysis](images/aspect_analysis.png) |

![Word cloud](images/wordcloud_positive.png)

## Repository Structure

```
.
├── chatgpt_review_analysis.ipynb   # full analysis (executed, with outputs)
├── data/chatgpt_reviews.csv        # dataset
├── images/                         # charts used in this README
├── requirements.txt
└── README.md
```

## How to Run

```bash
git clone <your-repo-url>
cd <repo-folder>
pip install -r requirements.txt
python -c "import nltk; nltk.download('stopwords')"
jupyter notebook chatgpt_review_analysis.ipynb
```

Then choose **Kernel > Restart & Run All** (sentiment scoring takes about a minute).

## Limitations & Future Work

- TextBlob is lexicon-based: it misses sarcasm, mixed reviews and romanised non-English text.
- Aspect keywords are approximate (a word can appear in praise or complaint).
- Most reviews are only 1 to 3 words, so explanations rely on the longer minority.
- Next steps: a transformer sentiment model, topic modelling (LDA / BERTopic), and comparing aspects around product releases.

## Tech Stack

Python, pandas, NumPy, TextBlob, scikit-learn, NLTK, WordCloud, Matplotlib, Seaborn, Jupyter.
